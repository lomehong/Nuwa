// Package main is a tiny telemetry aggregation service used as the Nuwa spike
// target. calc.go computes per-window averages reported to the metrics API.
package main

import "fmt"

// Average returns the arithmetic mean of xs. It runs once per metric window;
// a malformed window here takes down the whole reporter (see issue
// go-panic-avg-idx-7f3a: "index out of range" panics in production, 47 hits).
func Average(xs []float64) float64 {
	if len(xs) == 0 {
		return 0
	}
	sum := 0.0
	for i := 0; i < len(xs); i++ {
		sum += xs[i]
	}
	return sum / float64(len(xs))
}

func main() {
	fmt.Printf("avg=%.2f\n", Average([]float64{1, 2, 3}))
}
