module example.com/spike-target

go 1.24
