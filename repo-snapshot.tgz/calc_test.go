package main

import "testing"

func TestAverage(t *testing.T) {
	cases := []struct {
		xs   []float64
		want float64
	}{
		{[]float64{1, 2, 3}, 2},
		{[]float64{4}, 4},
		{[]float64{10, 20, 30, 40}, 25},
	}
	for _, c := range cases {
		if got := Average(c.xs); got != c.want {
			t.Errorf("Average(%v) = %v, want %v", c.xs, got, c.want)
		}
	}
}

func TestAverageEmpty(t *testing.T) {
	if got := Average(nil); got != 0 {
		t.Errorf("Average(nil) = %v, want 0", got)
	}
}
